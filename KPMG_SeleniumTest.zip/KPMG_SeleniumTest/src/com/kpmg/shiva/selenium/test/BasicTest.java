package com.kpmg.shiva.selenium.test;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.kpmg.shiva.selenium.core.GenericWrapper;

public class BasicTest extends GenericWrapper{
	
	@BeforeTest
	public void launchBrowser() {
		
		String url ="http://www.practiceselenium.com/";
		driver.get(url);		
		Reporter.log(String.format("Chrome browser is launched with URL: %s", url), true);
	}
	
	@Test
	public void placeOrderTest() throws IOException {
		
		click(By.xpath("//a[contains(text(),'Menu')]"));
		Reporter.log("Clicked on Menu<br/>");
		
		List<WebElement> list =wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[contains(@class,'wsb-element-text')]//strong")));
		
		for(WebElement ele:list) {
			
			System.out.println(ele.getText());
			
			Reporter.log(ele.getText());
		}
		
		click(By.xpath("//div[contains(@class,'wsb-element-button')]//a[contains(.,'Check Out')]"));
		
		sendKeys(By.id("email"), "seleniumtest@gmail.com");
		sendKeys(By.id("name"), "QA Tester");
		sendKeys(By.id("address"), "Glasgow City Centre");
		selectDropDown(By.id("card_type"), "Mastercard");
		sendKeys(By.id("card_number"), "9999 8888 7777 4444");
		sendKeys(By.id("cardholder_name"), "QA Tester");
		sendKeys(By.id("verification_code"), "221133");
		
		File file =((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		FileUtils.copyFile(file, new File("test-output//screenshots//screenshot.png"));
		
		click(By.xpath("//button[contains(.,'Place Order')]"));
		
		
//		Just put it for last screen checking, can be removable
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
	}

	
	@AfterTest
	public void closeBrowser() {
		driver.quit();
	
	}
}
