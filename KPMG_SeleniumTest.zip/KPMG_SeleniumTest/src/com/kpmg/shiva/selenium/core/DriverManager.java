package com.kpmg.shiva.selenium.core;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverManager {

	private WebDriver driver;
	
	public static ThreadLocal<DriverManager>  _driverManager = new ThreadLocal<DriverManager>() {

		protected DriverManager initialValue() {
			return new DriverManager();
		}

	};
	
	public void initBrowser() {
		
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	
	
	public static DriverManager getInstance() {
		return _driverManager.get();
	}
	
	public WebDriver getDriver() {
		
		if(driver==null) {
			initBrowser();
		}
		
		return driver;
	}
	
	public void close() {
		driver.quit();
	}
}
