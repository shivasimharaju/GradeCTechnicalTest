package com.kpmg.shiva.selenium.core;

import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GenericWrapper {

	protected WebDriver driver;
	protected WebDriverWait wait;
	
	int longWait =10;
	
	
	public GenericWrapper() {
		driver = DriverManager.getInstance().getDriver();
		wait = new WebDriverWait(driver, 10);
		
	}
	
	
	public void click(By by) {
		
		wait.until(new Function<WebDriver, Boolean>() {

			@Override
			public Boolean apply(WebDriver driver) {
				// TODO Auto-generated method stub
				new Actions(driver).moveToElement(driver.findElement(by)).click().build().perform();
				return true;
			}
		});
	}
	
	public void sendKeys(By by, String value) {
		wait.until(new Function<WebDriver, Boolean>() {

			@Override
			public Boolean apply(WebDriver driver) {
				// TODO Auto-generated method stub
				driver.findElement(by).sendKeys(value);
				return true;
			}
		});
	}
	
	public void selectDropDown(By by, String value) {
		
		Select select = new Select(driver.findElement(by));
		select.selectByVisibleText(value);
	}
	
	
}
